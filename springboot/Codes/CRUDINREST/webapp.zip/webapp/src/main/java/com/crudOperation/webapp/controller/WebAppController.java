package com.crudOperation.webapp.controller;

import com.crudOperation.webapp.model.UsersList;
import com.crudOperation.webapp.useDAO.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WebAppController {
    @Autowired
    UserDao userDaoObj;

    @RequestMapping("index")
    public  String index(){
        return "index.jsp";
    }

    @RequestMapping("addUser")
    public String addUser(UsersList user){
        userDaoObj.save(user);
        return  "index.jsp";
    }

    @RequestMapping("getUser")
    public ModelAndView getUser(@RequestParam int id){
        UsersList user = userDaoObj.findById(id).orElse(new UsersList());
        ModelAndView mov = new ModelAndView("getUser.jsp");
        mov.addObject("user", user);
        return mov;
    }

    @RequestMapping("deleteUser")
    public ModelAndView deleteUser(@RequestParam int id){
        UsersList user = userDaoObj.findById(id).orElse(new UsersList());
        userDaoObj.deleteById(id);
        ModelAndView mov = new ModelAndView("deleteUser.jsp");
        mov.addObject("user", user);
        return mov;
    }
}
